# -*- coding: utf-8 -*-

import electronic_invoice
import account_journal