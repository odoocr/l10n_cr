# -*- coding: utf-8 -*-
import json
import requests
import re
import random
import logging
from odoo.exceptions import UserError

_logger = logging.getLogger(__name__)

def get_clave(self, url, tipo_documento, consecutivo, sucursal_id, terminal_id):
    payload = {}
    headers = {}
    # get Clave MH
    payload['w'] = 'clave'
    payload['r'] = 'clave'
    if self.company_id.identification_id.id == 1:
        payload['tipoCedula'] = 'fisico'
    elif self.company_id.identification_id.id == 2:
        payload['tipoCedula'] = 'juridico'
    payload['tipoDocumento'] = tipo_documento
    payload['cedula'] = self.company_id.vat
    payload['codigoPais'] = '506'
    payload['consecutivo'] = consecutivo
    payload['situacion'] = 'normal'
    payload['codigoSeguridad'] = str(random.randint(1, 99999999))
    payload['sucursal'] = sucursal_id
    payload['terminal'] = terminal_id

    response = requests.request("POST", url, data=payload, headers=headers)
    response_json = response.json()
    return response_json


def make_xml_invoice(inv, tipo_documento, consecutivo, date, sale_conditions, medio_pago, total_servicio_gravado,
                     total_servicio_exento, total_mercaderia_gravado, total_mercaderia_exento, base_subtotal,
                     total_impuestos, total_descuento, lines, tipo_documento_referencia, numero_documento_referencia,
                     fecha_emision_referencia, codigo_referencia, razon_referencia, url, currency_rate):
    headers = {}
    payload = {}
    # Generar FE payload
    payload['w'] = 'genXML'
    if tipo_documento in ('FE','TE'):
        payload['r'] = 'gen_xml_fe'
    elif tipo_documento == 'NC':
        payload['r'] = 'gen_xml_nc'
    payload['clave'] = inv.number_electronic
    payload['consecutivo'] = consecutivo
    payload['fecha_emision'] = date
    payload['emisor_nombre'] = inv.company_id.name
    payload['emisor_tipo_indetif'] = inv.company_id.identification_id.code
    payload['emisor_num_identif'] = inv.company_id.vat
    payload['nombre_comercial'] = inv.company_id.commercial_name or ''
    payload['emisor_provincia'] = inv.company_id.state_id.code
    payload['emisor_canton'] = inv.company_id.county_id.code
    payload['emisor_distrito'] = inv.company_id.district_id.code
    payload['emisor_barrio'] = inv.company_id.neighborhood_id and inv.company_id.neighborhood_id.code or ''
    payload['emisor_otras_senas'] = inv.company_id.street
    payload['emisor_cod_pais_tel'] = inv.company_id.phone_code
    payload['emisor_tel'] = inv.company_id.phone and re.sub('[^0-9]+', '', inv.company_id.phone) or ''
    payload['emisor_email'] = inv.company_id.email
    if not inv.partner_id or not inv.partner_id.vat:
        payload['omitir_receptor'] = 'true'
    else:
        payload['receptor_nombre'] = inv.partner_id.name[:80]
        payload['receptor_tipo_identif'] = inv.partner_id.identification_id.code
        payload['receptor_num_identif'] = inv.partner_id.vat
        payload['receptor_provincia'] = inv.partner_id.state_id.code or ''
        payload['receptor_canton'] = inv.partner_id.county_id.code or ''
        payload['receptor_distrito'] = inv.partner_id.district_id.code or ''
        payload['receptor_barrio'] = inv.partner_id.neighborhood_id.code or ''
        payload['receptor_cod_pais_tel'] = inv.partner_id.phone_code
        payload['receptor_tel'] = inv.partner_id.phone and re.sub('[^0-9]+', '', inv.partner_id.phone) or ''
        match = re.match(r'^(\s?[^\s,]+@[^\s,]+\.[^\s,]+\s?,)*(\s?[^\s,]+@[^\s,]+\.[^\s,]+)$', inv.partner_id.email.lower())
        if match:
            payload['receptor_email'] = inv.partner_id.email
        else:
            payload['receptor_email'] = 'indefinido@indefinido.com'
    if tipo_documento == 'TE':
        payload['condicion_venta'] = sale_conditions
        payload['plazo_credito'] = '0'
        payload['cod_moneda'] = inv.company_id.currency_id.name
    else:
        payload['condicion_venta'] = sale_conditions
        payload['plazo_credito'] = inv.payment_term_id and inv.payment_term_id.line_ids[0].days or '0'
        payload['cod_moneda'] = inv.currency_id.name
    payload['medio_pago'] = medio_pago
    payload['tipo_cambio'] = currency_rate
    payload['total_serv_gravados'] = total_servicio_gravado
    payload['total_serv_exentos'] = total_servicio_exento
    payload['total_merc_gravada'] = total_mercaderia_gravado
    payload['total_merc_exenta'] = total_mercaderia_exento
    payload['total_gravados'] = total_servicio_gravado + total_mercaderia_gravado
    payload['total_exentos'] = total_servicio_exento + total_mercaderia_exento
    payload['total_ventas'] = total_servicio_gravado + total_mercaderia_gravado + total_servicio_exento + total_mercaderia_exento
    payload['total_descuentos'] = total_descuento
    payload['total_ventas_neta'] = base_subtotal
    payload['total_impuestos'] = total_impuestos
    payload['total_comprobante'] = base_subtotal + total_impuestos
    payload['otros'] = ''
    payload['detalles'] = lines

    if tipo_documento == 'NC':
        payload['infoRefeTipoDoc'] = tipo_documento_referencia
        payload['infoRefeNumero'] = numero_documento_referencia
        payload['infoRefeFechaEmision'] = fecha_emision_referencia
        payload['infoRefeCodigo'] = codigo_referencia
        payload['infoRefeRazon'] = razon_referencia

    response = requests.request("POST", url, data=payload, headers=headers)
    response_json = response.json()
    return response_json


def token_hacienda(inv, env, url):
    url = 'https://idp.comprobanteselectronicos.go.cr/auth/realms/rut-stag/protocol/openid-connect/token'

    data = {
        'client_id': env,
        'client_secret': '',
        'grant_type': 'password',
        'username': inv.company_id.frm_ws_identificador,
        'password': inv.company_id.frm_ws_password}

    try:
        response = requests.post(url, data=data)

    except requests.exceptions.RequestException as e:
        _logger.error('Exception %s' % e)
        raise Exception(e)

    return {'resp': response.json()}


def sign_xml(inv, tipo_documento, url, xml):
    payload = {}
    headers = {}
    payload['w'] = 'signXML'
    payload['r'] = 'signFE'
    payload['p12Url'] = inv.company_id.frm_apicr_signaturecode
    payload['inXml'] = xml
    payload['pinP12'] = inv.company_id.frm_pin
    payload['tipodoc'] = tipo_documento

    response = requests.request("POST", url, data=payload, headers=headers)
    response_json = response.json()
    return response_json


def send_file(inv, token, date, xml, env, url):
    headers = {}
    payload = {}
    payload['w'] = 'send'
    payload['r'] = 'json'
    payload['token'] = token
    payload['clave'] = inv.number_electronic
    payload['fecha'] = date
    payload['emi_tipoIdentificacion'] = inv.company_id.identification_id.code
    payload['emi_numeroIdentificacion'] = inv.company_id.vat
    payload['recp_tipoIdentificacion'] = inv.partner_id.identification_id.code
    payload['recp_numeroIdentificacion'] = inv.partner_id.vat
    payload['comprobanteXml'] = xml
    payload['client_id'] = env

    response = requests.request("POST", url, data=payload, headers=headers)
    response_json = response.json()
    return response_json


def consulta_documentos(self, inv, env, token_m_h, url, date_cr, xml_firmado):
    payload = {}
    headers = {}
    payload['w'] = 'consultar'
    payload['r'] = 'consultarCom'
    payload['client_id'] = env
    payload['token'] = token_m_h
    payload['clave'] = inv.number_electronic
    response = requests.request("POST", url, data=payload, headers=headers)
    response_json = response.json()
    estado_m_h = response_json.get('resp').get('ind-estado')

    # Siempre sin importar el estado se actualiza la fecha de acuerdo a la devuelta por Hacienda y
    # se carga el xml devuelto por Hacienda
    if inv.type == 'out_invoice' or inv.type == 'out_refund':
        # Se actualiza el estado con el que devuelve Hacienda
        inv.state_tributacion = estado_m_h
        inv.date_issuance = date_cr
        inv.fname_xml_comprobante = 'comprobante_' + inv.number_electronic + '.xml'
        inv.xml_comprobante = xml_firmado
    elif inv.type == 'in_invoice' or inv.type == 'in_refund':
        inv.fname_xml_comprobante = 'receptor_' + inv.number_electronic + '.xml'
        inv.xml_comprobante = xml_firmado
        inv.state_send_invoice = estado_m_h

    # Si fue aceptado o rechazado por haciendo se carga la respuesta
    if (estado_m_h == 'aceptado' or estado_m_h == 'rechazado') or (inv.type == 'out_invoice'  or inv.type == 'out_refund'):
        inv.fname_xml_respuesta_tributacion = 'respuesta_' + inv.number_electronic + '.xml'
        inv.xml_respuesta_tributacion = response_json.get('resp').get('respuesta-xml')

    # Si fue aceptado por Hacienda y es un factura de cliente o nota de crédito, se envía el correo con los documentos
    if estado_m_h == 'aceptado':
        if not inv.partner_id.opt_out:
            if inv.type == 'in_invoice' or inv.type == 'in_refund':
                email_template = self.env.ref('cr_electronic_invoice.email_template_invoice_vendor', False)
            else:
                email_template = self.env.ref('account.email_template_edi_invoice', False)

            attachments = []

            attachment = self.env['ir.attachment'].search(
                [('res_model', '=', 'account.invoice'), ('res_id', '=', inv.id),
                 ('res_field', '=', 'xml_comprobante')], limit=1)
            if attachment.id:
                attachment.name = inv.fname_xml_comprobante
                attachment.datas_fname = inv.fname_xml_comprobante
                attachments.append(attachment.id)

            attachment_resp = self.env['ir.attachment'].search(
                [('res_model', '=', 'account.invoice'), ('res_id', '=', inv.id),
                 ('res_field', '=', 'xml_respuesta_tributacion')], limit=1)
            if attachment_resp.id:
                attachment_resp.name = inv.fname_xml_respuesta_tributacion
                attachment_resp.datas_fname = inv.fname_xml_respuesta_tributacion
                attachments.append(attachment_resp.id)

            if len(attachments) == 2:
                email_template.attachment_ids = [(6, 0, attachments)]

                email_template.with_context(type='binary', default_type='binary').send_mail(inv.id,
                                                                                            raise_exception=False,
                                                                                            force_send=True)  # default_type='binary'

                # limpia el template de los attachments
                email_template.attachment_ids = [(5)]
