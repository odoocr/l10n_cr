# -*- coding: utf-8 -*-
# © 2016-2017 Akretion (http://www.akretion.com)
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl.html).

{'name': 'Onchange Helper',
 'version': '10.0.1.0.0',
 'summary': 'Technical module that ease execution of onchange in Python code',
 'author': 'Akretion,Camptocamp,Odoo Community Association (OCA)',
 'website': 'http://www.akretion.com',
 'license': 'AGPL-3',
 'category': 'Generic Modules',
 'depends': ['base'],
 'installable': True,
 }
