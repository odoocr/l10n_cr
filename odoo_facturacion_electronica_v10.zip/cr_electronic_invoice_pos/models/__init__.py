# -*- coding: utf-8 -*-

import electronic_invoice